package com.udemy.java.lambda;

@FunctionalInterface
public interface StringOperations {
    void accept(String s);
}
