package com.udemy.java;


public class TestMain {

    public static void main(String[] args) {

        // to quickly test


    }

}
