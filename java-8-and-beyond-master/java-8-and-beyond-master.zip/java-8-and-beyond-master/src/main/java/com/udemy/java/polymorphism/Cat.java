package com.udemy.java.polymorphism;

                  //IS A/AN
public class Cat extends Animal {


    @Override
    public void makeSound(){
        System.out.println("I am cat. meow....");
    }


}
