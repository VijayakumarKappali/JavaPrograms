package com.udemy.java.interfacepolymorphism;

public interface Alarm {

    void setAlarm();

}
