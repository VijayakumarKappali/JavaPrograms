package com.udemy.java.polymorphism;

public class Horse extends Animal {

    @Override
    public void walk(){
        System.out.println("I am galloping....");
    }

}
